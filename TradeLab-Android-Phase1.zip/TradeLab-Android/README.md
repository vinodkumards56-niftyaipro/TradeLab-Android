# TradeLab Android — Phase 1

Native Android paper-trading starter built with Kotlin and Jetpack Compose.

## Phase 1 features
- Editable virtual capital (default ₹50,000; change it in the app)
- NIFTY 50, BANK NIFTY and SENSEX watchlist placeholders
- Manual simulated BUY/SELL orders with quantity and entered price
- Basic order list and used-capital display
- GitHub Actions workflow to build a debug APK

## Important limitations
- No live market prices are connected. Watchlist values intentionally show `—`.
- Orders are local in-memory demo data and reset when the app process is recreated.
- No Upstox or Zerodha authentication, no broker API calls and no live orders.
- The displayed P&L is not yet calculated; this is the Phase 1 UI and paper-order foundation.

## Build
GitHub Actions builds `app/build/outputs/apk/debug/app-debug.apk` on push or manual workflow dispatch.
The workflow uploads an artifact named `TradeLab-debug-apk`.

## Toolchain
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Android SDK 35
