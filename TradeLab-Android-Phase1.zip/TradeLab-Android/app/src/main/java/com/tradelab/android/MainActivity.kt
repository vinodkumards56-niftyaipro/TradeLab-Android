package com.tradelab.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

private val Ink = Color(0xFF101828)
private val Muted = Color(0xFF667085)
private val Green = Color(0xFF12B76A)
private val Red = Color(0xFFF04438)
private val Navy = Color(0xFF14213D)
private val Surface = Color(0xFFF5F7FA)

data class PaperTrade(
    val symbol: String,
    val side: String,
    val quantity: Int,
    val entry: Double
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TradeLabApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeLabApp() {
    var capitalText by remember { mutableStateOf("50000") }
    var capital by remember { mutableDoubleStateOf(50000.0) }
    var symbol by remember { mutableStateOf("NIFTY 50") }
    var side by remember { mutableStateOf("BUY") }
    var qtyText by remember { mutableStateOf("1") }
    var priceText by remember { mutableStateOf("") }
    var trades by remember { mutableStateOf(listOf<PaperTrade>()) }
    var message by remember { mutableStateOf("Paper trading is ready. Market quotes are not connected.") }
    var selectedTab by remember { mutableIntStateOf(0) }

    val invested = trades.sumOf { it.quantity * it.entry }
    val closedPnl = 0.0
    val currency = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            secondary = Green,
            background = Surface,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Surface,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("TradeLab", fontWeight = FontWeight.Bold, color = Ink)
                            Text("PAPER TRADING • INDIA", fontSize = 10.sp, color = Muted, letterSpacing = 1.sp)
                        }
                    },
                    actions = {
                        Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFE8F7EF)) {
                            Text("PAPER MODE", modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                color = Color(0xFF087443), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                    }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.ShowChart, null) }, label = { Text("Overview") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Add, null) }, label = { Text("New order") })
                }
            }
        ) { padding ->
            if (selectedTab == 0) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                Text("VIRTUAL CAPITAL", color = Color(0xFFB8C4D9), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(8.dp))
                                Text(currency.format(capital), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(6.dp))
                                Text("Available capital • Demo account", color = Color(0xFFB8C4D9), fontSize = 12.sp)
                                Spacer(Modifier.height(18.dp))
                                OutlinedTextField(
                                    value = capitalText,
                                    onValueChange = { capitalText = it },
                                    label = { Text("Set virtual capital (₹)") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFF9DB5D8), unfocusedBorderColor = Color(0xFF7185A5),
                                        focusedLabelColor = Color(0xFFB8C4D9), unfocusedLabelColor = Color(0xFFB8C4D9)
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = {
                                    val parsed = capitalText.toDoubleOrNull()
                                    if (parsed != null && parsed > 0) {
                                        capital = parsed
                                        message = "Virtual capital updated."
                                    } else message = "Enter a valid capital greater than zero."
                                }) { Text("Update capital") }
                            }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricCard("OPEN TRADES", trades.size.toString(), Modifier.weight(1f))
                            MetricCard("USED CAPITAL", currency.format(invested), Modifier.weight(1f))
                        }
                    }
                    item {
                        SectionTitle("Market watch", "Live quotes not connected")
                    }
                    items(listOf("NIFTY 50", "BANK NIFTY", "SENSEX")) { name ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(name, fontWeight = FontWeight.SemiBold, color = Ink)
                                    Text("Waiting for broker market feed", color = Muted, fontSize = 11.sp)
                                }
                                Text("—", color = Muted, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                        }
                    }
                    item { SectionTitle("Paper positions", "${trades.size} orders") }
                    if (trades.isEmpty()) {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Text("No paper trades yet. Create your first simulated order from the New order tab.",
                                    modifier = Modifier.padding(18.dp), color = Muted)
                            }
                        }
                    } else {
                        items(trades.reversed()) { trade ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(trade.symbol, fontWeight = FontWeight.Bold, color = Ink)
                                        Text("${trade.side} • Qty ${trade.quantity} • ${currency.format(trade.entry)}",
                                            color = Muted, fontSize = 12.sp)
                                    }
                                    Text("PAPER", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    item {
                        Text(message, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
                        Text("Phase 1: simulated orders only. No broker connection and no real orders are sent.",
                            color = Muted, fontSize = 11.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item { Text("Create paper order", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink) }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Instrument", fontWeight = FontWeight.SemiBold)
                                var expanded by remember { mutableStateOf(false) }
                                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                                    OutlinedTextField(value = symbol, onValueChange = {}, readOnly = true,
                                        modifier = Modifier.fillMaxWidth().menuAnchor(),
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                        listOf("NIFTY 50", "BANK NIFTY", "SENSEX").forEach {
                                            DropdownMenuItem(text = { Text(it) }, onClick = { symbol = it; expanded = false })
                                        }
                                    }
                                }
                                Text("Order side", fontWeight = FontWeight.SemiBold)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(selected = side == "BUY", onClick = { side = "BUY" }, label = { Text("BUY") })
                                    FilterChip(selected = side == "SELL", onClick = { side = "SELL" }, label = { Text("SELL") })
                                }
                                OutlinedTextField(value = qtyText, onValueChange = { qtyText = it },
                                    label = { Text("Quantity") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = priceText, onValueChange = { priceText = it },
                                    label = { Text("Simulated entry price (₹)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    singleLine = true, modifier = Modifier.fillMaxWidth())
                                Button(
                                    onClick = {
                                        val qty = qtyText.toIntOrNull()
                                        val price = priceText.toDoubleOrNull()
                                        if (qty == null || qty <= 0 || price == null || price <= 0) {
                                            message = "Enter a valid positive quantity and simulated price."
                                        } else if (qty * price > capital) {
                                            message = "Order value exceeds virtual capital."
                                        } else {
                                            trades = trades + PaperTrade(symbol, side, qty, price)
                                            message = "Paper order added. No real order was placed."
                                            priceText = ""
                                            selectedTab = 0
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Place paper order") }
                                Text("This is a manual simulation using the price you enter. It is not a live market quote.",
                                    color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    item { Text(message, color = Muted, fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(7.dp))
            Text(value, color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
        Text(subtitle, color = Muted, fontSize = 10.sp)
    }
}
